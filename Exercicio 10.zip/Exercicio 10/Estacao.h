#ifndef __ESTACAO__
#define __ESTACAO__

class Estacao{
	private:
		int num;
		int quantEsperando[5];
	public:
		Estacao(int);
		//int* quantEsperando(int*&, int&)
};
#endif
