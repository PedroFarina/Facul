#ifndef __LINHA__
#define __LINHA__
#include "Trem.h"
#include "Estacao.h"

class Linha{
	private:
		Estacao estacoes[5];
		Trem trem;
	public:
		void mudarEstacao();
};
#endif
