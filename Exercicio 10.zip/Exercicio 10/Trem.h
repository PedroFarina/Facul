#ifndef __TREM__
#define __TREM__
#include "ListaLigada.h"

class Trem{
	private:
		ListaLigada vagoes;
		int quantMax;
		int quantMaxVagao;
	public:
		Trem(int);
		void embarcar(int, int&);
		void desembarcar(int, int);
		int verificarLotacao(int);
};
#endif
