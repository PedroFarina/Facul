#include "Estacao.h"
#include <stdlib.h>

Estacao::Estacao(int numero){
	num = numero;
	for(int i=0; i<5; i++){
		quantEsperando[i] = rand() % 1000;	
	}
}

//int* Estacao::quantEsperando(int*&quantEsperando, int& len){
	
//}
