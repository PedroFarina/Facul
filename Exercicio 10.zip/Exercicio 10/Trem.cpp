#include "ListaLigada.h"
#include <algorithm>
#include "Trem.h"

Trem::Trem(int quantMaxTrem){
	quantMax = quantMaxTrem;
	quantMaxVagao = quantMax/5;
	
	for(int i=0; i < 5; i++){
		vagoes.insereInicio(0);
	}
}

void Trem::embarcar(int numVagao, int& quantEmbarcar){
	int qntPassageiros = verificarLotacao(numVagao);
	int sobra = (quantEmbarcar + qntPassageiros) - quantMaxVagao;
	if(sobra > 0){
		quantEmbarcar = quantEmbarcar - sobra;
	}
	vagoes.alterarValor(numVagao, qntPassageiros + quantEmbarcar);
	quantEmbarcar = std::max(sobra, 0);
}

void Trem::desembarcar(int numVagao, int quantDesembarcar){
	int qntPassageiros;
	vagoes.acharItem(numVagao, qntPassageiros);
	if(quantDesembarcar > qntPassageiros){
		quantDesembarcar = qntPassageiros;
	}
	vagoes.alterarValor(numVagao, qntPassageiros - quantDesembarcar);
}

int Trem::verificarLotacao(int numVagao){
	int qntPassageiros;
	vagoes.acharItem(numVagao, qntPassageiros);
	return qntPassageiros;
}
