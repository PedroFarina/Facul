#ifndef __FILA__
#define __FILA__
#include "ListaLigada.h"

class Fila{
private:
    ListaLigada itens;
    int tamMAX; 
public:
	Fila();
    Fila(int);
    bool eVazia();
    int count();
    int enfileira(int);
    bool desenfileira(int &);
    bool ConsultarFila(int &);
    bool Procurar(int &);
    bool Procurar(int &, int &);
};
#endif
