#include <cstdlib>
#include "Celula.h"
#include "ListaLigada.h"

ListaLigada::ListaLigada() {
	prim = NULL;
	ult = NULL;
}

bool ListaLigada::eVazia() {
	return prim == NULL;
}

void ListaLigada::insereInicio(int i) {
	Celula * c = new Celula(i);
	c->setProx(prim);
	if(prim == NULL){
		ult = c;
	}
	prim = c;
}

void ListaLigada::insereFinal(int i) {
	Celula * c = new Celula(i);
	if(ult == NULL){
		prim = c;
	}
	else{
		ult->setProx(c);
	}
	ult = c;
}

bool ListaLigada::alterarValor(int indice, int valor){
	Celula * cursor;
	if(acharItem(indice, cursor)){
		cursor->setInfo(valor);
		return true;
	}
	else{
		return false;
	}
}

bool ListaLigada::insereNoIndice(int indice, int valor){
	Celula * cursor;
	Celula * nova = new Celula(valor);
	if(acharItem(indice - 1, cursor)){
		nova->setProx(cursor->getProx());
		cursor->setProx(nova);
		return true;
	}
	else{
		return false;
	}
}

bool ListaLigada::excluirIndice(int indice){
	if(indice == 0 && count() == 1){
		delete prim;
		prim = NULL;
		ult = NULL;
		return true;
	}
	Celula * cursor;
	Celula * proximoCursor;
	if(acharItem(indice - 1, cursor)){
		proximoCursor = cursor->getProx();
		proximoCursor = proximoCursor->getProx();
		delete cursor->getProx();
		if(proximoCursor == NULL){
			cursor->setProx(NULL);
			ult = cursor;
		}
		else{
			cursor->setProx(proximoCursor);	
		}
	}
	else if(indice == 0){
		Celula * cursor = prim;
		prim = cursor->getProx();
		delete cursor;
	}
	return true;
}

bool ListaLigada::acharItem(int indice, Celula *&Cursor){
	if(eVazia() || indice < 0){
		return false;
	}
	Celula* c = prim;
	int i = 0;
	while(c != NULL && i<indice){
		c = c -> getProx();
		i++;
	}
	Cursor = c;
	return Cursor != NULL;
}

bool ListaLigada::acharItem(int indice, int &elem){
	Celula* c;
	bool resposta = acharItem(indice, c);
	if(resposta){
		elem = c->getInfo();
	}
	return resposta;
}

int ListaLigada::acharIndice(int valor){
	Celula * cursor = prim;
	int i = 0;
	while(cursor != NULL && cursor->getInfo() != valor){
		cursor = cursor->getProx();
		i++;
	}
	if(cursor == NULL){
		return -1;
	}
	else{
		return i;
	}
}

int ListaLigada::count(){
	Celula * cursor = prim;
	int i = 0;
	while(cursor != NULL){
		cursor = cursor->getProx();
		i++;
	}
	return i;
}

int ListaLigada::somaValores() {
	Celula * cursor = prim;
	int resp = 0;
	while (cursor != NULL) {
		resp += cursor->getInfo();
		cursor = cursor->getProx();
	}
	return resp;
}

bool ListaLigada::Ultima(int &elem){
	if(ult == NULL) return false;
	elem = ult->getInfo();
	return true;
}

bool ListaLigada::Primeira(int &elem){
	if(prim == NULL) return false;
	elem = prim->getInfo();
	return true;
}
