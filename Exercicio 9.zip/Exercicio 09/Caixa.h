#ifndef __CAIXA__
#define __CAIXA__
#include "Fila.h"

class Caixa{
	private:
		Fila fila;
		int tamMAX;
	public:
		Caixa();
		Caixa(int);
		int tamAtual();
		int capacidade();
		bool consultarFila(int &);
		bool atender(int &);
		int enfileira(int);
		bool Procurar(int elem);
};
#endif
