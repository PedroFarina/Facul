#include "Edificio.h"
#include "Elevador.h"
#include "Caixa.h"

using namespace std;

Edificio::Edificio(int CapacidadeElevador, int CapacidadeCaixaPagamento, int CapacidadeCaixaRetirada){
	elevador = Elevador(CapacidadeElevador);
	CaixaPagamento = Caixa(CapacidadeCaixaPagamento);
	CaixaRetirada = Caixa(CapacidadeCaixaRetirada);
}

int Edificio::EntrarElevador(int idCliente, int andarCliente){
	if(!Contains(idCliente)){
		if(andarCliente == 0 && CaixaPagamento.tamAtual() + elevador.CargaAtual() == CaixaPagamento.capacidade()){
			return -2;
		}
		return elevador.Embarcar(idCliente, andarCliente);
	}
	return -1;
}

bool Edificio::UsarElevador(){
	if(elevador.MudarAndar(0)){
		elevador.Esvaziar();
		return true;
	}
	elevador.MudarAndar(1);
	int cl[elevador.Capacidade()];
	int len;
	int* clientes = elevador.Esvaziar(cl, len);
	for(int i=0; i < len; i++){
		EntrarFilaPagamento(*(clientes + i));
	}
	return true;
}

int Edificio::EntrarFilaPagamento(int idCliente){
	if(!Contains(idCliente)){
		return CaixaPagamento.enfileira(idCliente);
	}
	return 0;
}

int Edificio::PagarFilaPagamento(int &idCliente){
	if(CaixaRetirada.capacidade() == CaixaRetirada.tamAtual()){
		return 0;
	}
	int elem;
	if(CaixaPagamento.atender(elem)){
		idCliente = elem;
		return EntrarFilaRetirada(elem);
	}
	return -2;
}

int Edificio::EntrarFilaRetirada(int idCliente){
	if(!Contains(idCliente)){
		return CaixaRetirada.enfileira(idCliente);
	}
	return -1;
}

int Edificio::RetirarFilaRetirada(int &idCliente){
	int pFila;
	if(CaixaRetirada.consultarFila(pFila)){
		idCliente = pFila;
		int embarque = elevador.Embarcar(pFila, 1) + 3;
		if(embarque == 4){
			return CaixaRetirada.atender(pFila);
		}
		else{
			return embarque;
		}
	}
	return 0;
}


bool Edificio::Contains(int idCliente){
	return CaixaPagamento.Procurar(idCliente) || CaixaRetirada.Procurar(idCliente) || elevador.Procurar(idCliente);
}
