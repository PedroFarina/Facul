#include <iostream>
#include "Edificio.h"
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Edificio ed = Edificio(10, 20, 5);
	int numLido;
	string msg;
	while(true){
		cout << "Escolha uma opcao:\n1- Embarcar um cliente no elevador.\n2- Atender um cliente no caixa de pagamento.\n3- Atender um cliente no caixa de retirada.\n4- Alterar o elevador de andar.\n5- Terminar Execucao\n\n";
		cin >> numLido;
		switch (numLido){
			case 1:
				cout << "\nQual e o id do cliente?\n";
				cin >> numLido;
				msg = "Erro.";
				switch(ed.EntrarElevador(numLido, 0)){
					case -2:
						msg = "Nao ha espaco no caixa de pagamento para tantos clientes.";
						break;
					case -1:
						msg = "Este cliente ja esta em outro local.";
						break;
					case 0:
						msg = "O elevador esta cheio.";
					break;
					case 1:
						msg = "Sucesso.";
						break;
					case 2:
						msg = "O elevador esta em outro andar.";
						break;
				}
				break;
			case 2:
				msg = "Erro.";
				switch(ed.PagarFilaPagamento(numLido)){
					case -2:
						msg = "Nao ha clientes na fila.";
						break;
					case -1:
						msg = "Este cliente ja esta em outro local.";
						break;
					case 0:
						msg = "O caixa de retirada esta cheio. Favor antender um cliente de retirada antes.";
						break;
					case 1:
						cout << "O cliente " << numLido <<" foi atendido.";
						msg = "";
						break;		
				}
				break;
			case 3:
				msg = "Erro.";
				switch(ed.RetirarFilaRetirada(numLido)){
					case 0:
						msg = "Nao ha clientes na fila de retirada.";
						break;
					case 1:
						cout << "O cliente " << numLido << " foi atendido.";
						msg = "";
						break;
					case 2:
						msg = "Este cliente ja esta em outro local.";
						break;
					case 3:
						msg = "O elevador esta cheio.";
						break;
					case 5:
						msg = "O elevador esta em outro andar.";
						break;
				}
				break;
			case 4:
				if(ed.UsarElevador()){
					msg = "Os passageiros desembarcaram e seguiram seus respectivos destinos.";	
				}
				else{
					msg = "Falha.";
				}
				break;
			case 5:
				system("pause");
				return 0;
				break;
		}
		cout << msg << endl << endl;
	}
}
