#ifndef __EDIFICIO__
#define __EDIFICIO__
#include "Caixa.h"
#include "Elevador.h"

class Edificio{
	private:
		Elevador elevador;
		Caixa CaixaPagamento;
		Caixa CaixaRetirada;
	public:
		Edificio(int, int, int);
		int EntrarElevador(int, int);
		bool UsarElevador();
		int EntrarFilaPagamento(int);
		int PagarFilaPagamento(int &);
		int EntrarFilaRetirada(int);
		int RetirarFilaRetirada(int &);
		bool PegarItem();
		bool Contains(int);
};
#endif
