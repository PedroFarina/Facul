#ifndef __CELULA__
#define __CELULA__

class Celula {

	//= privado
	private:
	int info;
	Celula * prox;

	//= publico
	public:
	Celula(int);
	int  getInfo();
	void setInfo(int);
	Celula * getProx();
	void setProx(Celula * );
};
#endif

