#include "Caixa.h"

Caixa::Caixa(){
	fila = Fila();
}

Caixa::Caixa(int TamanhoMax){
	fila = Fila(TamanhoMax);
}

int Caixa::enfileira(int idCliente){
	return fila.enfileira(idCliente);
}

bool Caixa::atender(int &idCliente){
	return fila.desenfileira(idCliente);
}

bool Caixa::Procurar(int idCliente){
	return fila.Procurar(idCliente);
}

int Caixa::tamAtual(){
	return fila.count();
}

int Caixa::capacidade(){
	return tamMAX;
}

bool Caixa::consultarFila(int &elem){
	return fila.ConsultarFila(elem);
}
