#ifndef __ELEVADOR__
#define __ELEVADOR__
#include "Pilha.h"

class Elevador{
	private:
		Pilha elevador;
		int andarAtual;
		int capacidade;
	public:
		bool MudarAndar(int);
		int Embarcar(int, int);
		bool Esvaziar();
		int* Esvaziar(int[], int&);
		int Procurar(int);
		int Capacidade();
		int CargaAtual();
		Elevador();
		Elevador(int);
};
#endif
