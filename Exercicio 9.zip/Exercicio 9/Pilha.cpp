#include "Pilha.h"
#include <cstdlib>

// ------ IMPLEMENTACAO dos M�TODOS de Pilha
//     ou IMPLEMENTACAo das FUNCOES-MEMBRO de Pilha

Pilha::Pilha(){
	tamMAX = NULL;
}

Pilha::Pilha(int TamanhoMax){
    tamMAX = TamanhoMax;
}

bool Pilha::eVazia(){
    return itens.eVazia();
}

int Pilha::empilha(int elem){
	if(itens.count() == tamMAX){
		return 0;
	}
	else if(Procurar(elem)){
		return -1;
	}
    itens.insereFinal(elem);
    return 1;
}

bool Pilha::desempilha(int & elem){
	if(itens.Ultima(elem)){
		return itens.excluirIndice(itens.count() - 1);	
	}
	return false;
}

bool Pilha::consultarTopo(int & elem){
    if(eVazia()){
    	return false;
	}
	return itens.Ultima(elem);
}

bool Pilha::Procurar(int elem){
	int i;
	return Procurar(elem, i);
}

bool Pilha::Procurar(int elem, int &index){
	index = itens.acharIndice(elem);
	if(index != -1){
		return true;
	}
	else{
		return false;
	}
}

int Pilha::count(){
	return itens.count();
}
