#include <cstdlib>
#include "Celula.h"

//Feito por Pedro Giuliano Farina 31734391
//          Juan Juan             31711081
//          Leonardo Longato 	  31717543

Celula::Celula(int i) {
	info =  i;
	prox = NULL;
}

int Celula::getInfo() {
	return info;
}

void Celula::setInfo(int i) {
	info = i;
}

Celula * Celula::getProx() {
	return prox;
}

void Celula::setProx(Celula * p) {
	prox = p;
}
