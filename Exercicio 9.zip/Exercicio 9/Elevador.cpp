#include "Pilha.h"
#include "Elevador.h"

using namespace std;

Elevador::Elevador(){
	elevador = Pilha();
	andarAtual = 0;
}

Elevador::Elevador(int TamanhoMax){
	capacidade = TamanhoMax;
	elevador = Pilha(TamanhoMax);
	andarAtual = 0;
}

bool Elevador::MudarAndar(int targetAndar){
	if(targetAndar == andarAtual){
		return false;
	}
	andarAtual = targetAndar;
	return true;
}

int Elevador::Embarcar(int idCliente, int andar){
	if(andar == andarAtual){
		return elevador.empilha(idCliente);	
	}
	return 2;
}

int* Elevador::Esvaziar(int arg[], int &len){
	int elem;
	len = 0;
	while(elevador.desempilha(elem)){
		arg[len] = elem;
		len++;
	}
	return arg;
}

int Elevador::Procurar(int idCliente){
	return elevador.Procurar(idCliente);
}

int Elevador::Capacidade(){
	return capacidade;
}

int Elevador::CargaAtual(){
	return elevador.count();
}

bool Elevador::Esvaziar(){
	int elem;
	while(elevador.desempilha(elem)){
	}
	return true;
}
