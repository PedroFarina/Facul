#ifndef __CELULA__
#define __CELULA__

//Feito por Pedro Giuliano Farina 31734391
//          Juan Juan             31711081
//          Leonardo Longato 	  31717543

class Celula {

	//= privado
	private:
	int info;
	Celula * prox;

	//= publico
	public:
	Celula(int);
	int  getInfo();
	void setInfo(int);
	Celula * getProx();
	void setProx(Celula * );
};
#endif

