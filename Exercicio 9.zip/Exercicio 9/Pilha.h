#ifndef __PILHA__
#define __PILHA__
#include "ListaLigada.h"

class Pilha{
private:
    ListaLigada itens;
    int tamMAX;
public:
	Pilha();
    Pilha(int);
    bool eVazia();
    bool eCheia();
    int empilha(int);
    int count();
    bool desempilha(int &);
    bool consultarTopo(int&);
    bool Procurar(int);
    bool Procurar(int, int &);
};
#endif
