#include "Fila.h"
#include <cstdlib>
// ------ IMPLEMENTACAO dos M�TODOS de Fila
//     ou IMPLEMENTACAo das FUNCOES-MEMBRO de Fila

Fila::Fila(){
	tamMAX = 32767;
}

Fila::Fila(int TamanhoMaximo){
    tamMAX = TamanhoMaximo;
}

bool Fila::eVazia(){
    return (itens.eVazia());
}

int Fila::enfileira(int elem){
    if (itens.count() == tamMAX)
        return 0;
    itens.insereFinal(elem);
    return 1;
}

bool Fila::desenfileira(int & elem){
    if (eVazia())
        return false;
    if(itens.Primeira(elem)){
    	return itens.excluirIndice(0);	
	}
    return false;
}

bool Fila::ConsultarFila(int &elem){
	return itens.Primeira(elem);
}

bool Fila::Procurar(int & elem){
	int i;
	return Procurar(elem, i);
}
bool Fila::Procurar(int & elem, int & index){
	index = itens.acharIndice(elem);
	if(index != -1){
		elem = itens.acharItem(index, elem);
	}
	else{
		return false;
	}
}

int Fila::count(){
	return itens.count();
}
