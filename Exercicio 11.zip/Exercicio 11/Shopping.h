#ifndef __SHOPPING__
#define __SHOPPING__
#include "Caixa.h"

class Shopping{
	private:
		Caixa c;
		int minutosPassados;
		int CriarPessoa();
		int numPessoasChegando();
		bool desistencia;
	public:
		Shopping(bool);
		void PassarHoras(int);
		void PassarHora();
		void PassarMinuto();
		void Resultado(int&, double&, int&);
		void Resultado(int&, double&, int&, int&);
};

#endif
