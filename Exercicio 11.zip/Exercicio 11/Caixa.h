#ifndef __CAIXA__
#define __CAIXA__
#include "Fila.h"


class Caixa{
	private:
		Fila f;
		int quantAtendida;
		int tempoTomado;
		int numDesistentes;
	public:
		Caixa();
		Caixa(bool);
		int EntrarNaFila(int);
		bool SairDaFila();
		bool Consultar(int&);
		int TamanhoFila();
		void Resultados(int&, double&, int&, int&);
};
#endif
