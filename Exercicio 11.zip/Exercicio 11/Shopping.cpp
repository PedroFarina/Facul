#include "Caixa.h"
#include "Shopping.h"
#include <cstdlib>
#include <stdio.h>
#include <time.h>
#include <iostream>
using namespace std;

Shopping::Shopping(bool desistir){
	c = Caixa(desistir);
	desistencia = desistir;
	minutosPassados = 0;
}

void Shopping::PassarHoras(int numHoras){
	for(int i=0;i<numHoras;i++){
		PassarHora();
	}
}

void Shopping::PassarHora(){
	for(int i=0;i<60;i++){
		PassarMinuto();
	}
}

void Shopping::PassarMinuto(){
	int tempoNecessario;
	srand(time(NULL));
	if(c.Consultar(tempoNecessario)){
		if(tempoNecessario <= minutosPassados){
			c.SairDaFila();
			minutosPassados = 0;
		}
	}
	for(int i=0;i<numPessoasChegando(); i++){
		c.EntrarNaFila(CriarPessoa());
	}
	minutosPassados++;
}

void Shopping::Resultado(int &numAtendidos, double &tempoMedio, int &numNaoAtendidos){
	int numDesistiram;
	Resultado(numAtendidos, tempoMedio, numNaoAtendidos, numDesistiram);
}

void Shopping::Resultado(int &numAtendidos, double &tempoMedio, int &numNaoAtendidos, int &numDesistiram){
	c.Resultados(numAtendidos, tempoMedio, numNaoAtendidos, numDesistiram);
	c = Caixa(desistencia);
}

int Shopping::CriarPessoa(){
	int probabilidade = rand() % 100 + 1;
	int retorno;
	if(probabilidade > 0 && probabilidade <= 15){
		retorno = 1;
	}
	else if(probabilidade > 15 && probabilidade <= 65){
		retorno = 2;
	}
	else if(probabilidade > 65 && probabilidade <= 90){
		retorno = 3;
	}
	else{
		retorno = 5;
	}
	return retorno;
}

int Shopping::numPessoasChegando(){
	int probabilidade = rand() % 100 + 1;
	int retorno;
	if(probabilidade > 0 && probabilidade <= 30){
		retorno = 0;
	}
	else if(probabilidade > 30 && probabilidade <= 70){
		retorno = 1;
	}
	else if(probabilidade > 70 && probabilidade <= 95){
		retorno = 2;
	}
	else{
		retorno = 3;
	}
	return retorno;
}
