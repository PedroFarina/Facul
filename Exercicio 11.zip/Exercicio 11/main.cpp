#include "Shopping.h"
#include <iostream>
#include <cstdlib>

using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Shopping s = Shopping(false);
	int numAtendidos, numRestantes, numDesistiram;
	double tempoMedio;
	
	cout << "Simulacao com pessoas com paciencia para esperar mais de 5 pessoas na fila.\n";
	s.PassarHoras(3);
	s.Resultado(numAtendidos, tempoMedio, numRestantes);
	if(numAtendidos != 0){
		cout << numAtendidos << " cliente(s) foram atendidos.\nO tempo medio de atendimento foi " << tempoMedio << " minuto(s).\nRestaram " << numRestantes << " pessoa(s) na fila.\n\n";
	}
	else{
		cout << "Nao houve clientes hoje.\n\n";
	}
	
	cout << "Simulacao com pessoas sem paciencia para esperar mais de 5 pessoas na fila.\n";
	s = Shopping(true);
	s.PassarHoras(3);
	s.Resultado(numAtendidos, tempoMedio, numRestantes, numDesistiram);
	if(numAtendidos != 0){
		cout << numAtendidos << " cliente(s) foram atendidos.\nO tempo medio de atendimento foi " << tempoMedio << " minuto(s).\nRestaram " << numRestantes << " pessoa(s) na fila.\nDevido a fila maior de 5 pessoas, " << numDesistiram << " pessoa(s) desistiram de ir ao caixa.\n";
	}
	else{
		cout << "Nao houve clientes hoje.\n";
	}
}
