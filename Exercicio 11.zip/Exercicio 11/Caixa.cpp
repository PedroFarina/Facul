#include "Caixa.h"

Caixa::Caixa(){
}

Caixa::Caixa(bool desistencia){
	if(desistencia){
		f = Fila(5);	
	}
	tempoTomado = 0;
	quantAtendida = 0;
	numDesistentes = 0;
}

int Caixa::EntrarNaFila(int tempo){
	int result = f.enfileira(tempo);
	if(result == 0){
		numDesistentes++;
	}
	return result;
}

bool Caixa::SairDaFila(){
	int tempoInd;
	bool retorno = f.desenfileira(tempoInd);
	if(retorno){
		for(int i=0;i < f.count() + 1;i++){
			tempoTomado += tempoInd;
		}
		quantAtendida++;
	}
	return retorno;
}

bool Caixa::Consultar(int &elem){
	return f.ConsultarFila(elem);
}

int Caixa::TamanhoFila(){
	return f.count();
}

void Caixa::Resultados(int &numAtendidos, double &tempoMedio, int &numNaoAtendidos,int &numDesistiram){
	numAtendidos = quantAtendida;
	tempoMedio = 0;
	if(tempoTomado != 0 && quantAtendida != 0){
		tempoMedio = tempoTomado/quantAtendida;
	}
	numNaoAtendidos = f.count();
	numDesistiram = numDesistentes;
}
