#ifndef __LISTALIGADA__
#define __LISTALIGADA__
#include "Celula.h"

class ListaLigada{
	private:
	Celula * prim;
	Celula * ult;
	public:
	ListaLigada();
	bool eVazia();
	void insereInicio(int);
	void insereFinal(int);
	bool insereNoIndice(int, int);
	bool alterarValor(int, int);
	bool excluirIndice(int);
	bool acharItem(int, Celula *&);
	bool acharItem(int, int &);
	int acharIndice(int);
	bool Ultima(int &);
	bool Primeira(int &);
	int count();
	void imprime();
	int  somaValores();
};
#endif
