#include <cstdlib>
#include <iostream>
#include "Celula.h"
#include "ListaLigada.h"

//Feito por Pedro Giuliano Farina 31734391
//          Juan Juan             31711081
//          Leonardo Longato 	  31717543

using namespace std;


ListaLigada::ListaLigada() {
	prim = NULL;
	ult = NULL;
}

bool ListaLigada::eVazia() {
	return prim == NULL;
}

void ListaLigada::insereInicio(int i) {
	Celula * c = new Celula(i);
	c->setProx(prim);
	if(prim == NULL){
		ult = c;
	}
	prim = c;
}

void ListaLigada::insereFinal(int i) {
	Celula * c = new Celula(i);
	if(ult == NULL){
		prim = c;
	}
	else{
		ult->setProx(c);
	}
	ult = c;
}

bool ListaLigada::alterarValor(int indice, int valor){
	Celula * cursor;
	if(acharItem(indice, cursor)){
		cursor->setInfo(valor);
		return true;
	}
	else{
		return false;
	}
}

bool ListaLigada::insereNoIndice(int indice, int valor){
	Celula * cursor;
	Celula * nova = new Celula(valor);
	if(acharItem(indice - 1, cursor)){
		nova->setProx(cursor->getProx());
		cursor->setProx(nova);
		return true;
	}
	else{
		return false;
	}
}

bool ListaLigada::excluirIndice(int indice){
	Celula * cursor;
	Celula * proximoCursor;
	if(acharItem(indice - 1, cursor)){
		proximoCursor = cursor->getProx();
		proximoCursor = proximoCursor->getProx();
		delete cursor->getProx();
		cursor->setProx(proximoCursor);
	}
}

bool ListaLigada::acharItem(int indice, Celula *&Cursor){
	if(eVazia()){
		return false;
	}
	Celula* c = prim;
	int i = 0;
	while(c != NULL && i<indice){
		c = c -> getProx();
		i++;
	}
	Cursor = c;
	return Cursor != NULL;
}

int ListaLigada::count(){
	Celula * cursor = prim;
	int i = 0;
	while(cursor != NULL){
		cursor = cursor->getProx();
		i++;
	}
	return i;
}

void ListaLigada::imprime() {
	Celula * cursor = prim;
	cout << "[ ";
	while (cursor != NULL) {
		cout << cursor->getInfo() << " ";
		cursor = cursor->getProx();
	}
	cout << "]\n";
}

int ListaLigada::somaValores() {
	Celula * cursor = prim;
	int resp = 0;
	while (cursor != NULL) {
		resp += cursor->getInfo();
		cursor = cursor->getProx();
	}
	return resp;
}

