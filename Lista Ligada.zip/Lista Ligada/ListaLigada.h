#include "Celula.h"

//Feito por Pedro Giuliano Farina 31734391
//          Juan Juan             31711081
//          Leonardo Longato 	  31717543

class ListaLigada {
	
	//= privado
	private:
	Celula * prim;
	Celula * ult;
	
	//= publico
	public:
	ListaLigada();
	bool eVazia();
	void insereInicio(int);
	void insereFinal(int);
	bool insereNoIndice(int, int);
	bool alterarValor(int, int);
	bool excluirIndice(int);
	bool acharItem(int, Celula *&);
	int count();
	void imprime();
	int  somaValores();
	// ... outros m�todos ...
	
};
