#include <cstdlib>
#include <iostream>
#include "ListaLigada.h"

//Feito por Pedro Giuliano Farina 31734391
//          Juan Juan             31711081
//          Leonardo Longato 	  31717543

using namespace std;

int main(int argc, char * argv[]) {
	ListaLigada umaL;
	int index = 0;
	int numLido = 0;
	while(true){
		cout << "Menu de interacao\n 1- Inserir no comeco da lista.\n 2- Inserir no final da lista.\n 3- Alterar o valor do elemento na posicao.\n 4- Inserir um elemento na posicao n da lista.\n 5- Excluir um elemento na posicao n da lista.\n 6- Contar os elementos da lista.\n 7- Imprimir elementos da lista.\n 0- Sair.\n\n";
		cin >> numLido;
		switch(numLido){
			case 1:
				cout << "\nFavor insira um numero: ";
				cin >> numLido;
				cout << endl;
				umaL.insereInicio(numLido);
				cout << "O numero " << numLido << " foi inserido no comeco da lista.\n";
			break;
			case 2:
				cout << "\nFavor insira um numero: ";
				cin >> numLido;
				cout << endl;
				umaL.insereFinal(numLido);
				cout << "O numero " << numLido << " foi inserido no final da lista.\n";
				break;
			case 3:
				cout << "\nFavor insira o indice a ser mudado: ";
				index = 0;
				cin >> index;
				cout << "\nFavor insira o novo valor: ";
				cin >> numLido;
				if(umaL.alterarValor(index, numLido)){
					cout << "\nSucesso.\n";
				}
				else{
					cout << "\nFalha.\n";
				}
				break;
			case 4:
				cout << "\nFavor insira o indice a inserir o elemento: ";
				index = 0;
				cin >> index;
				cout << "\nFavor insira o valor: ";
				cin >> numLido;
				if(umaL.insereNoIndice(index, numLido)){
					cout << "\nSucesso.\n";
				}
				else{
					cout << "\nFalha.\n";
				}
				break;
			case 5:
				cout << "\nFavor insira o indice a excluir o elemento: ";
				index = 0;
				cin >> index;
				if(umaL.excluirIndice(index)){
					cout << "\nSucesso.\n";
				}
				else{
					cout << "\nFalha.\n";
				}
				break;
			case 6:
				cout << umaL.count() << "\n";
				break;
			case 7:
				umaL.imprime();
				break;
			case 0:
				system("PAUSE");
				return EXIT_SUCCESS;
				break;
		}
	}
}
