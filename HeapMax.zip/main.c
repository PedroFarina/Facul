#include <stdio.h>
#include <stdlib.h>

//Feito por Pedro Giuliano Farina 31734391
//          Leonardo Zoccal Longato 31717543

void afunda(int *v, int indiceAnterior, int indiceAtual){
	int aux;
	aux = *(v + indiceAnterior);
	*( v + indiceAnterior) = *(v + indiceAtual);
	*(v + indiceAtual) = aux;
}

void heapMax(int *v, int size, int quantFilhos){
	int i, i2, aux;
	for(i = 1; i < size/quantFilhos; i ++){
		
		for(i2 = 0; i2 < quantFilhos; i2++){
			aux = (i * quantFilhos) + i2;
			if(*(v + i) < *(v + aux)){
				afunda(v, i, aux);
			}
		}
		
	}
}


int main(int argc, char *argv[]) {
	int matriz[8] = {0, 1, 20, 10, 15, 12, 8, 7};
	
	heapMax(matriz, 8, 2);
	int i;
	
	for(i = 0; i<8; i++){
		printf("%d ", matriz[i]);
	}
	
	return 0;
}
