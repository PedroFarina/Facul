

#define TAM 4

class Fila{
private:
    int itens[TAM];
    int fim; 
public:
    Fila();
    bool eVazia();
    int enfileira(int);
    bool desenfileira(int &);
    int ConsultarFila();
    bool Procurar(int &);
    bool Procurar(int &, int &);
};
