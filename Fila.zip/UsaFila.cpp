#include <cstdlib>
#include <iostream>
#include "Fila.h" 

using namespace std;

void desenfileirar(Fila & f){
	int out;
	if(f.desenfileira(out)) cout << "Voce desenfileirou o item: " << out << "\n";
	else cout << "A fila esta vazia.\n";
}
// ----------------- Funcao main
int main(){
    Fila f;
    int   numLido;
    while (true){
    	cout << "Escolha uma opcao:\n0 - Sair\n1 - Incluir um item na fila\n2 - Atender um item da fila\n3 - Consultar o numero de itens da fila\n4 - Esvaziar a fila\n5 - Procurar item\n";
    	cin >> numLido;
    	cout << endl;
    	if(numLido ==0) break;
    	else if(numLido == 1){
    		cout << "Digite o numero que voce deseja enfileirar.\n";
    		cin >> numLido;
    		int result = f.enfileira(numLido);
    		if(result == 1) cout << "O numero foi enfileirado.\n";
    		else if(result == 0) cout << "O numero nao foi enfileirado pois a fila encontra-se cheia.\n";
    		else if(result == -1) cout << "O numero ja foi enfileirado anteriormente.\n";
		}
		else if(numLido == 2){
			desenfileirar(f);
		}
		else if(numLido == 3){
			cout << "O numero de elementos na fila e: " << f.ConsultarFila() << "\n";
		}
		else if(numLido == 4){
			while (!f.eVazia()){
     		    desenfileirar(f);
        	}
    	}
    	else if(numLido == 5){
    		cout << "Digite o numero que voce deseja procurar.\n";
    		cin >> numLido;
    		int index;
    		if(f.Procurar(numLido, index)) cout << "O numero: " << numLido << " encontra-se na " << index + 1 << "a posicao da lista\n";
    		else cout << "O numero nao esta na lista.\n";
		}
		cout << endl;
	}
    system("PAUSE");
    return 0;
}
