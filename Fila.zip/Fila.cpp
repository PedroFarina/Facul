#include "Fila.h"

// ------ IMPLEMENTACAO dos M�TODOS de Fila
//     ou IMPLEMENTACAo das FUNCOES-MEMBRO de Fila

Fila::Fila(){
    fim = 0;
}

bool Fila::eVazia(){
    return (fim == 0);
}

int Fila::enfileira(int elem){
    if (fim == TAM)
        return 0;
    else if(Procurar(elem)){
    	return -1;
	}
    itens[fim]= elem;
    fim++;
    return 1;
}

bool Fila::desenfileira(int & elem){
    if (eVazia())
        return false;
    elem= itens[0];
    for (int k=0; k< fim-1; k++)
        itens[k]= itens[k+1];
    fim--;
    return true;
}

int Fila::ConsultarFila(){
	return fim;
}

bool Fila::Procurar(int & elem){
	int i;
	return Procurar(elem, i);
}
bool Fila::Procurar(int & elem, int & index){
	for(index = 0; index < fim; index++){
		if(itens[index] == elem)return true;
	}
	return false;
}
