//Desenvolvido por Pedro Giuliano Farina 31734391

#include <iostream>
#include "ArvoreGenerica.h"

using namespace std;

//= metodo inicializador
ArvoreGenerica::ArvoreGenerica() {

}

//= retorna a quantidade de nos da arvore
int ArvoreGenerica::tamanhoArvore() {
	return TAMANHO;
}

bool ArvoreGenerica::limpaArvore() {

	for (int i = 0; i < 100; i++) {
		arvore[i][0] = 0;
		arvore[i][1] = 0;

		//cout << arvore[i][0] << " - " << arvore[i][1] << endl;
	}

}

//= acha a raiz da arvore: procurar um pai (coluna 0) que nao aparece como filho (coluna 1)
int ArvoreGenerica::raiz() {
	bool achou = true;
	//= indice i vai correr a coluna dos pais e j a dos filhos
	for (int i = 0; i < TAMANHO; i++) {
		for (int j = 0; j < TAMANHO; j++) {
			if (arvore[j][1] == arvore[i][0]) {
				achou = false;
				break;
			}
		}
		if (achou) {
			return arvore[i][0];
		} else {
			achou = true;
		}
	}
	return 0;
}

bool ArvoreGenerica::inclui(int pai, int filho) {

	for (int i = 0; i < TAMANHO; i++) {

		if (arvore[i][0] == 0) {
			arvore[i][0] = pai;
			arvore[i][1] = filho;
			return true;
		}

	}
	return false;

}

//= imprime o array da composicao da arvore (pai - filho)
void ArvoreGenerica::imprimeArray() {

	for (int i = 0; i < TAMANHO; i++) {
		if ( arvore[i][0] > 0) {
			cout << arvore[i][0] << " - " << arvore[i][1] << endl;
		} else {
			return;
		}
	}

}


//= retorna vetor com os filhos de um determinado no' (n)
int * ArvoreGenerica::getFilhos(int n) {
	
	int numero = 0;

	for (int i = 0; i < TAMANHO; i++) {
		if (arvore[i][0] == n) {
			filhos[numero] = arvore[i][1];
			numero++;
		}
	}
	filhos[numero] = 0;

	return filhos;

}

//= retorna o n�mero do pai de um determinado n� (n)
bool ArvoreGenerica::getPai(int n, int& pai){
	for(int i=0; i<TAMANHO; i++){
		if(arvore[i][1] == n){
			pai = arvore[i][0];
			return true;
		}
	}
	return false;
}

//= retorna a profundidade de um n� de acordo com seus 'irm�os' (13 - 20, 13 - 2, 13 - 14) 20 -> 1, 3 -> 2, 14 -> 3.
bool ArvoreGenerica::getProfundidade(int n, int&prof){
	prof = 0;
	if(n == raiz()) return true;
	int pai;
	if(getPai(n, pai)){
		int* filhos;
		filhos = getFilhos(pai);
		while(filhos[prof] > 0 && filhos[prof] != n){
			prof++;
		}
		prof++;
		return true;
	}
	return false;
}

//= retorna a profundidade de uma sub�rvore come�ando em n.
bool ArvoreGenerica::getSubProfundidade(int n, int& prof){
	prof = 0;
	if(n == raiz()) return true;
	while(getPai(n, n)){
		prof++;
	}
	return prof!=0;
}

//= Imprime a subarvore a partir de um n� n
void ArvoreGenerica::imprimeSubArvore(int n){
	for (int i = 0; i < TAMANHO; i++) {
		if ( arvore[i][0] > 0) {
			int pai = arvore[i][0];
			while(pai!=n && getPai(pai, pai))
			{
			}
			if(pai == n){
				cout << arvore[i][0] << " - " << arvore[i][1] << endl;	
			}
		} else {
			return;
		}
	}
}
