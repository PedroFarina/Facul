//Desenvolvido por Pedro Giuliano Farina 31734391

#include <iostream>
#include <stdlib.h>
#include "ArvoreGenerica.h"

using namespace std;

void carregaArvore(ArvoreGenerica * ag);
void pausa();
void executa();

int main() {

	ArvoreGenerica * ag = new ArvoreGenerica();

	carregaArvore(ag);

	int opc;

	while (true) {

		system("cls");
		cout << "\n0 - sair";
		cout << "\n1 - achar raiz";
		cout << "\n2 - filhos de um no'";
		cout << "\n3 - pai de um no'";
		cout << "\n4 - profundidade de um no'";
		cout << "\n5 - profundidade de uma subarvore";
		cout << "\n6 - localizar um elemento e listar seus ancestrais (ate' chegar ao raiz)";
		cout << "\n7 - imprimir uma subarvore 'a partir de um no'";

		cout << "\n9 - imprime array da arvore";

		cout << "\n\nOpcao: ";
		cin >> opc;
		
		int filho, prof, pai, *filhos;
		switch(opc) {
		case 0:
			return 0;
		case 1:
			cout << "A raiz da arvore e': " << ag->raiz() << endl;
			pausa();
			break;
		case 2:
			cout << "Numero do no' pai: ";
			int opc2;
			cin >> opc2;
			filhos = ag->getFilhos(opc2);

			int num;
			num = 0;

			cout << "[ ";
			while (true) {
				if (filhos[num] > 0) {
					cout << filhos[num] << " ";
					num++;
				} else break;
			}
			cout << "]";

			pausa();
			break;
		case 3:
			cout << "Numero do no filho\n";
			cin >> filho;
			if(ag->getPai(filho, pai)){
				cout << pai;	
			}
			else{
				cout << "Este numero nao se encontra como filho na arvore.";
			}
			pausa();
			break;
		case 4:
			cout << "Numero do no\n";
			cin >> filho;
			if(ag->getProfundidade(filho, prof)){
				cout << prof;
			}
			else{
				cout << "Este numero nao se encontra na arvore";
			}
			pausa();
			break;
		case 5:
			cout << "Numero do no\n";
			cin >> filho;
			if(ag->getSubProfundidade(filho, prof)){
				cout << prof;
			}
			else{
				cout << "Este numero nao se encontra na arvore";
			}
			pausa();
			break;
		case 6:
			cout << "Numero do no\n";
			cin >> filho;
			while(ag->getPai(filho, pai)){
				cout << filho << " e filho de " << pai << endl;
				filho = pai;
			}
			
			pausa();
			break;
		case 7:
			cout << "Numero do no\n";
			cin >> filho;
			
			ag -> imprimeSubArvore(filho);
			pausa();
			break;
		case 9:
			ag->imprimeArray();
			pausa();
			break;
		}





	}



}

void carregaArvore(ArvoreGenerica * ag) {

	ag->limpaArvore();

	ag->inclui(13, 20);
	ag->inclui(13, 3);
	ag->inclui(13, 17);
	ag->inclui(13, 8);
	ag->inclui(13, 2);
	ag->inclui(20, 6);
	ag->inclui(20, 11);
	ag->inclui(17, 18);
	ag->inclui(17, 22);
	ag->inclui(17, 5);
	ag->inclui(2, 15);
	ag->inclui(2, 7);
	ag->inclui(6, 1);
	ag->inclui(6, 12);
	ag->inclui(6, 14);
	ag->inclui(22, 19);
	ag->inclui(22, 21);
	ag->inclui(22, 9);
	ag->inclui(22, 16);
	ag->inclui(21, 10);
	ag->inclui(21, 4);


}




void pausa() {
	cout << endl;
	system("pause");
}
