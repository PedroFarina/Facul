//Desenvolvido por Pedro Giuliano Farina 31734391

#define TAMANHO 100
#define QTD_MAX_FILHOS 10

class ArvoreGenerica {

	//==========================================================================
	public:
	//==========================================================================
	ArvoreGenerica();
	int raiz();
	bool limpaArvore();
	bool inclui(int pai, int filho);
	int tamanhoArvore();
	void imprimeArray();
	void imprimeSubArvore(int n);
	bool getPai(int n, int& pai);
	int * getFilhos(int n);
	int * getAncestrais(int n);
	bool getProfundidade(int n, int& prof);
	bool getSubProfundidade(int n, int& prof);
	int filhos[QTD_MAX_FILHOS];
	//--------------------------------------------------------------------------

	//==========================================================================
	private:
	//==========================================================================
	
	int arvore[TAMANHO][2];
	//--------------------------------------------------------------------------


};
