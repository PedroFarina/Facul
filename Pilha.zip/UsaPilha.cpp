#include <cstdlib>
#include <iostream>
#include "Pilha.h" 

using namespace std;

// ----------------- Funcao main
int main(){
    Pilha s;
    int numLido;
    
    if (s.eVazia())
        cout << "Pilha esta vazia\n";
    else
        cout << "Pilha nao esta vazia\n";
        
    while (true){
        cout << "\n\n0 - Sair.\n1 - Empilhar\n2 - Desempilhar\n3 - Consultar capacidade\n4 - Consultar elemento topo\n5 - Esvaziar a pilha\n6 - Ver somatoria da pilha\nDigite um numero: ";
        cin >> numLido;
        cout << endl;
        if (numLido == 0){
            break;
        }
        else if (numLido == 1){
            cout << "Digite um numero para empilhar: ";
            cin >> numLido;
            cout << endl;
            if(s.empilha(numLido)){
            	cout << "O numero foi empilhado.";	
			}
			else{
				cout << "A pilha esta cheia.";
			}
        }
        else if(numLido == 2){
            int out;
            if(s.desempilha(out)){
                cout << "Voce desempilhou o numero: " << out << endl;                
            }
            else{
                cout << "A pilha esta vazia" << endl;
            }
        }
        else if(numLido == 3){
            int Total, Restante;
            Total = s.consultarCapacidade(Restante);
            cout << "Ha " << Restante << " posicoes restantes de " << Total << " posicoes." << endl;
        }
        else if(numLido == 4){
            int item;
            if(s.consultarTopo(item)){
                cout << item << endl;
            }
            else{
                cout << "A pilha esta vazia" << endl;
            }
        }
        else if(numLido == 5){
        	bool ProfessorPermitePointer = true;
        	int len;
        	if(ProfessorPermitePointer){	//M�todo de esvaziar usando um pointer caso
            	int *p;
            	p = s.esvaziar(len);
            	for(int i=0; i<len; i++){
	                cout << *(p + i) << endl;
    	        }	
			}
            else{
            	int aux;
            	s.consultarCapacidade(len);
            	for(int i=0; i<len; i++){
            		s.desempilha(aux);
            		cout << aux << endl;
				}
			}
        }
        else if(numLido == 6){
        	cout << "A soma dos valores da pilha e: " << s.soma();
		}
    }
    while(!s.eVazia()){
    	int aux;
    	s.desempilha(aux);
    	cout << aux << endl;
	}
    system("PAUSE");
    return 0;
}
