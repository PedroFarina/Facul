#include "Pilha.h"

// ------ IMPLEMENTACAO dos M�TODOS de Pilha
//     ou IMPLEMENTACAo das FUNCOES-MEMBRO de Pilha

Pilha::Pilha(){
    topo = 0;
}

bool Pilha::eVazia(){
    return (topo == 0);
}

bool Pilha::eCheia(){
    return (topo==TAM);
}

bool Pilha::empilha(int elem){
    if (eCheia())
        return false;
    somatoria += elem;
    itens[topo]= elem;
    topo++;
    return true;
}

bool Pilha::desempilha(int & elem){
    if (eVazia())
        return false;
    topo--;
    elem= itens[topo];
    somatoria -= elem;
    return true;
}

bool Pilha::consultarTopo(int & elem){
    if(eVazia()){
    	return false;
	}
    elem = itens[topo-1];
    return true;
}

int Pilha::consultarCapacidade(int &Capacidade){
    Capacidade = TAM - topo;
    return TAM;
}

int* Pilha::esvaziar(int &Len){
    Len = topo;
    topo = 0;
    return itens;
}

int Pilha::soma(){
	return somatoria;
}
