#define TAM 4

class Pilha{
private:
    int itens[TAM];
    int topo;
    int somatoria;
public:
    Pilha();
    bool eVazia();
    bool eCheia();
    bool empilha(int);
    bool desempilha(int &);
    int consultarCapacidade(int &);
    bool consultarTopo(int &);
    int * esvaziar(int &);
    int soma();
};
